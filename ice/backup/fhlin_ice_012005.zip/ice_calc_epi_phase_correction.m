function [ice_obj]=ice_calc_epi_phase_correction(ice_obj)

odd=ice_obj.nav{2};         %from line "1"
even=ice_obj.nav{1};        %from line "0"

odd2=odd(1:end-1,:);
odd1=odd(2:end,:);
even2=even(1:end-1,:);
even1=even(2:end,:);

odd_linear_angle=angle(diag(odd1'*odd2));
even_linear_angle=angle(diag(even1'*even2));

offset=angle(diag(even'*odd));

ice_obj.nav_phase_slope=odd_linear_angle-even_linear_angle;
ice_obj.nav_phase_offset=offset;
ice_obj.nav_phase_offset=zeros(length(offset),1);

return;