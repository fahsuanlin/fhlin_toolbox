function [ok, ice_obj]=ice_do_per_image_volume(sMdh, ice_obj)
global ice_m_data;

ok=1;


    %re-orienat image such that rows are freq. encoding and cols are phase
    %encoding

if(~ice_obj.flag_3D)
    %ice_obj.m_data=permute(ice_obj.m_data,[2 1 3 4]);
    ice_m_data=permute(ice_m_data,[2 1 3 4]);
end;

if(ice_obj.flag_3D)
	fprintf('3D FFT...\n');
	%ice_obj.m_data=fftshift(fft(fftshift(ice_obj.m_data,3),[],3),3);
	ice_m_data=fftshift(fft(fftshift(ice_m_data,2),[],2),2);
	ice_m_data=fftshift(fft(fftshift(ice_m_data,3),[],3),3);
	
	fprintf('flipping S-I direction...\n');
	ice_m_data=flipdim(ice_m_data,1);
	
	fprintf('re-dimension into AX slices...\n');
	ice_m_data=permute(ice_m_data,[2 3 1 4]);
	
	ice_obj.m_Nz=size(ice_m_data,3);
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%		modify here for your own file archiving routines.
%%%%

for s=1:ice_obj.m_Nz
    for ch=1:ice_obj.m_NChan
	if(ice_obj.flag_init)
		fn=sprintf('%s_slice%03d_chan%03d_re.bfloat',ice_obj.output_stem,s,ch);
        	%fmri_svbfile(real(ice_obj.m_data(:,:,s,ch)),fn);
        	fmri_svbfile(real(ice_m_data(:,:,s,ch)),fn);
        	fn=sprintf('%s_slice%03d_chan%03d_im.bfloat',ice_obj.output_stem,s,ch);
	        %fmri_svbfile(imag(ice_obj.m_data(:,:,s,ch)),fn);
		fmri_svbfile(imag(ice_m_data(:,:,s,ch)),fn);
	else
	        fn=sprintf('%s_slice%03d_chan%03d_re.bfloat',ice_obj.output_stem,s,ch);
        	%fmri_svbfile(real(ice_obj.m_data(:,:,s,ch)),fn,'append');
        	fmri_svbfile(real(ice_m_data(:,:,s,ch)),fn,'append');
        	fn=sprintf('%s_slice%03d_chan%03d_im.bfloat',ice_obj.output_stem,s,ch);
	        %fmri_svbfile(imag(ice_obj.m_data(:,:,s,ch)),fn,'append');
		fmri_svbfile(imag(ice_m_data(:,:,s,ch)),fn,'append');
	end;
    end;
end;

%%%%
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%reset init flag for the 2nd and following measurements.
if(ice_obj.flag_init) ice_obj.flag_init=0; end;

if(~ice_obj.flag_3D)
    %re-orient image dimension back to init.
    %ice_obj.m_data=permute(ice_obj.m_data,[2 1 3 4]);
    ice_m_data=permute(ice_m_data,[2 1 3 4]);
else
	fprintf('flipping back S-I direction...\n');
	ice_m_data=flipdim(ice_m_data,1);
	
	fprintf('re-dimension back...\n');
	ice_m_data=permute(ice_m_data,[3 1 2 4]);
	
	ice_obj.m_Nz=size(ice_m_data,3);
end;

return;
