function [ok, ice_obj]=ice_do_per_line(sMdh, sFifo, ice_obj)

global ice_m_data;

ok=1;

if(strcmp(ice_obj.idea_ver,'VA21'))
    ice_va21_def;
end;

if(strcmp(ice_obj.idea_ver,'VA15'))
    ice_va15_def;
end;

if(ice_obj.flag_regrid)
	% %// Regrid data.
	[ok, sFifo] =ice_trapezoid_regrid( sFifo, ice_obj.trapezoid);
	if ( ~ok )
    		fprintf('\nERROR regridding!\n');
    		return;
	end;  
end;

%// reflect Data if required
[ok, sFifo]=ice_reflectline(sFifo, sMdh, ice_obj.idea_ver);
if (~ok) return; end;

%// No 'shake-in' of data into FT buffer is necessary prior to X FT for magnitude images.
sFifo.FCData=fftshift(fft(fftshift(sFifo.FCData,1),[],1),1);

if(ice_obj.flag_regrid)
	%// Correct the roll-off due to the regridding convolution.
	[ok, sFifo] = ice_trapezoid_rolloff( sFifo, ice_obj.trapezoid);
	if ( ~ok )
    		fprintf('\nERROR applying the roll-off correction for regridding.\n ');
    	return;           
	end;
end;

%// clip out center part (remove oversampling);
sFifo.FCData=sFifo.FCData(sFifo.lDimX/2-sFifo.lDimX/4+1:sFifo.lDimX/2+sFifo.lDimX/4,:);
sFifo.lDimX=sFifo.lDimX/2;

%// Put the line into either the reference or data object.
PHASE_COR=ice_check_phase_cor(sMdh,ice_obj);

if (PHASE_COR)  %// reference data (3 lines) for EPI phase correction
    lY = sMdh.sLC.ushSeg;  %// these lines use the segment counter (0 or 1)
    
    %// Handle averages
    if(sMdh.sLC.ushAcquisition>0)
        ice_obj.nav{lY+1}=(ice_obj.nav{lY+1}.*sMdh.sLC.ushAcquisition+sFifo.FCData)./(sMdh.sLC.ushAcquisition+1);
    else
        ice_obj.nav{lY+1}=sFifo.FCData;
    end;
    
    %// Calculate the EPI phase correction after getting the 3rd line.
    if ( sMdh.sLC.ushAcquisition == 1 )
        [ice_obj]=ice_calc_epi_phase_correction( ice_obj);
    end;
else
    %// Handle averages
    if(sMdh.sLC.ushAcquisition>0)
        if(~ice_obj.flag_3D)
            %2D sequence
            ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:)=(ice_obj.m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:).*sMdh.sLC.ushAcquisition+sFifo.FCData)./(sMdh.sLC.ushAcquisition+1);
        else
            %3D sequence
            ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushPartition+1,:)=(ice_obj.m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushPartition+1,:).*sMdh.sLC.ushAcquisition+sFifo.FCData)./(sMdh.sLC.ushAcquisition+1);
        end;
    else
        %save FIFO into data buffer
        if(~ice_obj.flag_3D)
            %2D sequence
            ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:)=sFifo.FCData;
        else
            %3D sequence
            %ice_obj.m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushPartition+1,:)=sFifo.FCData;
            ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushPartition+1,:)=sFifo.FCData;
        end;
    end;

    ODD_LINE=ice_check_odd_line(sMdh, ice_obj);

    if ( ODD_LINE )
        ice_obj = ice_apply_epi_phase_correction(sMdh, sFifo, ice_obj);
    end;
end;

return;
