function ice_master(varargin)

file_prot='meas.asc';
file_raw='meas.out';

flag_VA21=1;
flag_VA15=0;
idea_ver='VA21';
flag_debug=0;
output_stem='meas';
flag_scan_mdh_only=0;

if(nargin==0)
	file_prot='meas.asc';
	file_raw='meas.out';
	file_stem='meas';
	fprintf('using [meas.asc] and [meas.out] as input files.\n');
else
	for i=1:length(varargin)/2
		option=varargin{i*2-1};
		option_value=varargin{i*2};
		
		switch(lower(option))
		case 'file_prot'
			file_prot=option_value;
			fprintf('protocol file = [%s]\n',file_prot);
		case 'file_raw'
			file_raw=option_value;
			fprintf('raw data file = [%s]\n',file_raw);				
		case 'file_debug'
			flag_debug=option_value;
			if(flag_debug)
				fprintf('debug ON! flag_debug = [%d]\n',flag_debug);				
			else
				fprintf('debug OFF!\n');				
			end;
		case 'flag_scan_mdh_only'
			flag_debug=option_value;	
			if(flag_scan_mdh_only)
				fprintf('Scanning MDH in [%s[ without reading raw data!\n',file_raw);				
			else
				fprintf('Scanning MDH and reading reaw data! [%s]\n',file_raw);				
			end;
		end;
	end;
end;
			
	

fprintf('reading protocol [%s]...\n',file_prot);
MrProt=ice_read_prot(file_prot);

fprintf('reading raw data [%s]...\n',file_raw);
fp=fopen(file_raw);

%// Compute images only when raw data streaming is turned off.
%///////////////////////////////////////////////////////////////////////////
%////////////////////////// Call of Prepare Function ///////////////////////
%///////////////////////////////////////////////////////////////////////////
%// Do ICE preparation for image computations

[ice_obj]= ice_prepare(MrProt);

ice_obj.flag_debug=flag_debug;
ice_obj.idea_ver=idea_ver;
ice_obj.output_stem=output_stem;

%// Open the output file for writing.
%// This will be available in IceFake_online (..., etc.) through the protocol (MrProt).
%fp_out=fopen(file_output,'w');

%//
%// Allocate complex floating point data for each ADC read.
%//
lNxOverSamp     = 2 * MrProt.lBaseResolution;    %// Actual n
lLengthFifoData = lNxOverSamp * MrProt.lNumberOfChannels;
sFifo.FCData    = zeros(lNxOverSamp,MrProt.lNumberOfChannels);

%///////////////////////////////////////////////////////////////////////////
%////////////////////// Begin reading the input file ///////////////////////
%///////////////////////////////////////////////////////////////////////////
%// Open the file for reading.
file_in=fopen(file_raw,'r');

%// There are 32 bytes on top (uninteresting, as far as I can tell).
dummy = fread( file_in,8,'long');
if ( length(dummy)~=8 )
    fprintf('\nError reading the top 32 bytes (error = %d).\n', length(dummy)*4);
    return;
end;
if (flag_debug>= 2 )
    for j=0:7
        fprintf('dummy[%d] = %d\n',j,dummy(j+1));
    end;
end;

if(flag_VA21)
    ice_va21_def;
end;
%//
%// Begin the loop of MDH, FIFO, MDH, FIFO, ...
%//
flag_cont=1;
fprintf('accessing raw data...\n');

sLC_max=zeros(1,9);

while (flag_cont) 
   
    if(flag_VA21)
        sMdh=ice_read_mdh_va21(file_in);
    end;
    
    sLC_now=[sMdh.sLC.ushRepetition,sMdh.sLC.ushSlice,sMdh.sLC.ushSeg,sMdh.sLC.ushLine,sMdh.sLC.ushAcquisition,sMdh.sLC.ushPartition,sMdh.sLC.ushEcho,sMdh.sLC.ushPhase,sMdh.sLC.ushSet];
    sLC_max=max(cat(1,sLC_now,sLC_max),[],1);
    
    if (flag_debug)
        
        fprintf(' =================== MDH %d =======================\n',sMdh.ulScanCounter);
        fprintf('# samples in scan   = %d\n',sMdh.ushSamplesInScan);
        if ( sMdh.ushUsedChannels ~= 1 )
            fprintf('# channels = %d, channel ID = %d\n',sMdh.ushUsedChannels,sMdh.ulChannelId);
        end;
        %// Special flags:
        fprintf('flags: ');
        if(flag_VA15)
            if ( sMdh.ulEvalInfoMask & MDH_PHASCOR )               fprintf('PhaseCor ');        end;
            if ( sMdh.ulEvalInfoMask & MDH_FIRSTSCANINSLICE )      fprintf('FirstInSlice ');    end;
            if ( sMdh.ulEvalInfoMask & MDH_LASTSCANINSLICE )       fprintf('LastInSlice ');     end;
            if ( sMdh.ulEvalInfoMask & MDH_REFLECT )               fprintf('Reflect ');         end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_REFPHASESTABSCAN )  fprintf('RefNav');           end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_PHASESTABSCAN )     fprintf('Nav');              end;
        end;
        if(flag_VA21)
            if ( sMdh.aulEvalInfoMask(1) & MDH_PHASCOR )           fprintf('PhaseCor ');        end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_FIRSTSCANINSLICE )  fprintf('FirstInSlice ');    end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_LASTSCANINSLICE )   fprintf('LastInSlice ');     end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_REFLECT )           fprintf('Reflect ');         end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_REFPHASESTABSCAN )  fprintf('RefNav');           end;
            if ( sMdh.aulEvalInfoMask(1) & MDH_PHASESTABSCAN )     fprintf('Nav');              end;
        end;
        fprintf('\n');
        %//	  printf(' --------------- LOOP COUNTERS -----------------\n');
        fprintf('REP = %d, SLC = %d, SEG = %d, LIN = %d\n',...
            sMdh.sLC.ushRepetition,sMdh.sLC.ushSlice,sMdh.sLC.ushSeg,sMdh.sLC.ushLine);
        fprintf('ACQ = %d, PAR = %d, ECO = %d, PHS = %d, SET = %d\n',...
            sMdh.sLC.ushAcquisition,sMdh.sLC.ushPartition,sMdh.sLC.ushEcho,sMdh.sLC.ushPhase,sMdh.sLC.ushSet);
        if(flag_VA15)
            fprintf('FRE = %d\n',sMdh.sLC.ushFree);
        end;
        if(flag_VA21)
            fprintf('FRE = %d %d %d %d %d\n',sMdh.sLC.ushIda,...
                sMdh.sLC.ushIdb,sMdh.sLC.ushIdc,sMdh.sLC.ushIdd,sMdh.sLC.ushIde);
        end;
        
        if ( flag_debug >= 2 )
            fprintf('DMA length          = %d\n',sMdh.ulDMALength);
            fprintf('measurement user ID = %d\n',sMdh.lMeasUID);
            fprintf('time stamp          = %d\n',sMdh.ulTimeStamp);
            fprintf('PMU time stamp      = %d\n',sMdh.ulPMUTimeStamp);
            fprintf(' ----------------------------------------------\n');
            fprintf('filled zeros (pre)  = %d\n',sMdh.sCutOff.ushPre);
            fprintf('filled zeros (post) = %d\n',sMdh.sCutOff.ushPost);
            fprintf('center line of echo = %d\n',sMdh.ushKSpaceCentreColumn);
            fprintf('swapping variable   = %d\n',sMdh.ushDummy);
            fprintf('Readout offcenter   = %f\n',sMdh.fReadOutOffcentre);
            fprintf('time since last RF  = %d\n',sMdh.ulTimeSinceLastRF);
            fprintf('k-space center line = %d\n',sMdh.ushKSpaceCentreLineNo);
            fprintf('k-space center part = %d\n',sMdh.ushKSpaceCentrePartitionNo);
            fprintf('free parameter[1]   = %d\n',sMdh.aushFreePara(1));
            fprintf('free parameter[2]   = %d\n',sMdh.aushFreePara(2));
            fprintf('free parameter[3]   = %d\n',sMdh.aushFreePara(3));
            fprintf('free parameter[4]   = %d\n',sMdh.aushFreePara(4));
            fprintf('slice position      = %f %f %f\n',sMdh.sSD.sSlicePosVec.flSag,...
                sMdh.sSD.sSlicePosVec.flCor,...
                sMdh.sSD.sSlicePosVec.flTra);
            fprintf('slice rot. matrix   = %f %f %f %f\n',sMdh.sSD.aflQuaternion(1),...
                sMdh.sSD.aflQuaternion(2),...
                sMdh.sSD.aflQuaternion(3),...
                sMdh.sSD.aflQuaternion(4));
            
        end;
    end;
    
    %//
    %// An extra MDH at the end indicates the end of file.
    %//
    if(flag_VA15)
        if (bitand(sMdh.ulEvalInfoMask, MDH_ACQEND) ) flag_cont=0; break; end;
    end;
    
    if(flag_VA21)
        if (bitand(sMdh.aulEvalInfoMask(1), MDH_ACQEND) ) flag_cont=0; break; end;
    end;
    
    %  //
    %  // Error checking: the number of ADC samples should be lNxOverSamp (oversampling).
    %  //
    if ( sMdh.ushSamplesInScan ~= lNxOverSamp )
        
        fprintf(' ******** Consistency error in ADC %d *************\n',sMdh.ulScanCounter);
        fprintf(' ******** ADC samples (%d) ~= expected samples (%d)\n\n',...
            sMdh.ushSamplesInScan, lNxOverSamp);
    end;
    
    %// Set the fifo length according to the data length in the 1st channel.
    if ( sMdh.ulChannelId == 0 )
        sFifo.lDimX =  sMdh.ushSamplesInScan;
        sFifo.lDimXOp = sMdh.ushSamplesInScan;
        sFifo.lDimC = sMdh.ushUsedChannels;
    else
        %// Other channels should have the same FIFO length.
        if ( sMdh.ushSamplesInScan ~= sFifo.lDimX )
            fprintf('\nError~~ Different ADC lengths in different channels~\n');
            return;
        end;
    end;

    data=fread(file_in, (sFifo.lDimX)*2,'float');

    if (length(data)~=sFifo.lDimX*2)
        printf('\nError reading data for ADC %d.\n',sMdh.ulScanCounter);
        break;
    end;                
    cdata=data(1:2:end)+data(2:2:end).*sqrt(-1);
    sFifo.FCData(:,sMdh.ulChannelId+1)=transpose(cdata);
    
    %// Process data only after all channels have been read.
    if ( (sMdh.ulChannelId == sMdh.ushUsedChannels - 1 )&~flag_scan_mdh_only)
        %//
        %// Call the 'online' IceFake function when all channels have been read.
        %// Note that the structure of the raw data file (e.g., 'meas.out')
        %// separates channels with headers (sMdh), but all channels are 1st combined
        %// here in order to simulate the way it is done on the scanner, where
        %// one call of the online function has all the channel data.
        %//
         [ok,ice_obj]= ice_online( sMdh, sFifo, ice_obj);
%         if ( ~ok )
%             fprintf('\nError returned from IceFake_online.\n');
%             return;
%         end;
    end;
    
end;

fprintf('accumulated MDH counter info:\n');
fprintf('REP = %d, SLC = %d, SEG = %d, LIN = %d\n',...
            sLC_max(1),sLC_max(2),sLC_max(3),sLC_max(4));
fprintf('ACQ = %d, PAR = %d, ECO = %d, PHS = %d, SET = %d\n',...
            sLC_max(5),sLC_max(6),sLC_max(7),sLC_max(8),sLC_max(9));
            
fclose(file_in);

%ok = IceFake_offline;
fprintf('DONE!\n\n');

return;
    
