function [do_what]=ice_react_on_flags(sMdh, ice_obj)

if(~ice_obj.flag_3D)
	lSlice=sMdh.sLC.ushSlice;
else
	lSlice=sMdh.sLC.ushPartition;
end;

if(strcmp(ice_obj.idea_ver,'VA21'))
    ice_va21_def;
end;

if(strcmp(ice_obj.idea_ver,'VA15'))
    ice_va15_def;
end;

LAST_SCAN =bitand (sMdh.aulEvalInfoMask(1),  MDH_LASTSCANINSLICE);


if(~ice_obj.flag_3D)
	%// This is image data (2D encoding).
	if ( LAST_SCAN )
		if ( lSlice ==ice_obj.m_Nz - 1 )
			%// This is the last line in an image volume.
			do_what = 'DO_PER_IMAGE_VOLUME';
		else
			%// This is the last line in an image.
			do_what = 'DO_PER_IMAGE';
		end;  
	else
		%// This is not the last line in an image.
		do_what = 'DO_PER_LINE';
		%   //
		%   // lSlice keeps track of the volumes.  This allows the slice
		%   // counter (sMDH->ushSlice) to mark the anatomical (rather
		%   // than chronological) slice number.
		%   //
	end;
else
	%// This is image data (3D encoding).
	if ( LAST_SCAN )
		if ( lSlice ==ice_obj.m_Nz - 1 )
			%// This is the last line in an image volume.
			do_what = 'DO_PER_IMAGE_VOLUME';
		else
			%// This is the last line in an image.
			do_what = 'DO_PER_IMAGE';
		end;  
	else
		%// This is not the last line in an image.
		do_what = 'DO_PER_LINE';
		%   //
		%   // lSlice keeps track of the volumes.  This allows the slice
		%   // counter (sMDH->ushSlice) to mark the anatomical (rather
		%   // than chronological) slice number.
		%   //
	end;
end;

if ( LAST_SCAN )
    lSlice=lSlice+1;
end;

if ( lSlice == ice_obj.m_Nz ) 
    lSlice=0;
end;

return;
