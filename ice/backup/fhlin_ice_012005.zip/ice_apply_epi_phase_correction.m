function [ice_obj]=ice_apply_epi_phase_correction(sMdh, sFifo, ice_obj)

global ice_m_data;

x=([0:sFifo.lDimX-1]-sFifo.lDimX/2+0.5)';
x=repmat(x,[1, sFifo.lDimC]);
offset=repmat(transpose(ice_obj.nav_phase_offset),[size(x,1),1]);
phi=exp(sqrt(-1).*(offset+x*diag(ice_obj.nav_phase_slope)));

%ice_obj.m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:)=squeeze(ice_obj.m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:)).*phi;
ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:)=squeeze(ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:)).*phi;

return;