function [data, data_combined]=ice_show(varargin)

data=[];
data_combined=[];

output_stem='meas';
time_idx='end';

dummy_idx=[];
flag_phase_detrend=0;

for i=1:length(varargin)/2
        option=varargin{i*2-1};
        option_value=varargin{i*2};
        
        switch(lower(option))
            case 'output_stem'
                output_stem=option_value;
                fprintf('output_stem = [%s]\n',output_stem);
	    case 'time_idx'
		time_idx=option_value;
	    case 'dummy_idx'
		dummy_idx=option_value;
	    case 'flag_phase_detrend'
		flag_phase_detrend=option_value;
        end;
end;
    

slice=1;
cont=1;
while(cont)
	d=dir(sprintf('*slice%03d*',slice));
	if(isempty(d))
		cont=0;
		slice=slice-1;
	else
		slice=slice+1;
	end;
end;
fprintf('[%d] slice.\n',slice);

chan=1;
cont=1;
while(cont)
        d=dir(sprintf('*chan%03d*',chan));
        if(isempty(d))
                cont=0;
                chan=chan-1;
        else
                chan=chan+1;
        end;
end;
fprintf('[%d] channels.\n',chan);

dre=fmri_ldbfile(sprintf('%s_slice001_chan001_re.bfloat',output_stem));
dre=mean(dre,3);
[rr,cc]=size(dre);
data=zeros(rr,cc,slice,chan);

for s=1:slice
	fprintf('slice [%03d]...\n',s);
	for c=1:chan
		fprintf('chan [%03d]...\r',c);
		dre=fmri_ldbfile(sprintf('%s_slice%03d_chan%03d_re.bfloat',output_stem,s,c));
		dre(:,:,dummy_idx)=[];
		switch(time_idx)
			case 'end'
				dre=dre(:,:,end);
			case 'begin'
				dre=dre(:,:,1);
			case 'mean'
				dre=mean(dre,3);
			otherwise
				data=zeros(rr,cc,slice,chan,size(dre,3));
		end;

                dim=fmri_ldbfile(sprintf('%s_slice%03d_chan%03d_im.bfloat',output_stem,s,c));
                dim(:,:,dummy_idx)=[];
		switch(time_idx)
                        case 'end'
                                dim=dim(:,:,end);
                        case 'begin'
                                dim=dim(:,:,1);
                        case 'mean'
                                dim=mean(dim,3);
			otherwise
                end;

		if(ndims(data)==4)
			data(:,:,s,c)=dre+sqrt(-1).*dim;
		else
			data(:,:,s,c,:)=dre+sqrt(-1).*dim;
		end;
	end;
	fprintf('\n');
end;

if(flag_phase_detrend)
	fprintf('detrending linear phase');
	for c=1:size(data,4)
		fprintf('*');
		for s=1:size(data,3)
			d=squeeze(data(:,:,s,c,:));
			k=fftshift(ifft(fftshift(fftshift(ifft(fftshift(d,1),[],1),1),2),[],2),2);
			r_idx=round(size(k,1)/2)+1;
			c_idx=round(size(k,2)/2)+1;
			k_center=angle(squeeze(k(r_idx,c_idx,:)));
			D=[ones(1,length(k_center)); 1:length(k_center)]';
			beta=inv(D'*D)*D'*k_center;
			k_center_linear_phase=beta(2);
			k=k.*permute(repmat(exp(sqrt(-1).*D(:,2).*(-k_center_linear_phase)),[1 size(k,1) size(k,2)]),[2 3 1]);
			d=fftshift(fft(fftshift(fftshift(fft(fftshift(k,1),[],1),1),2),[],2),2);
			data(:,:,s,c,:)=d;
		end;
	end;
	fprintf('\n');
end;

data_combined=squeeze(sqrt(mean(abs(data).^2,4)));

return;

