function []=ice_calc_epi_phase_correction(sMdh)

global ice_obj;

odd=ice_obj.nav{sMdh.sLC.ushSlice+1,2};         %from line "1"
even=ice_obj.nav{sMdh.sLC.ushSlice+1,1};        %from line "0"

if(~isempty(even)&~isempty(odd))    
     %use the biggest (1-fraction) proportion of the data to estimate phase
     %shift
     if(~isfield(ice_obj,'nav_data_fraction'))
         ice_obj.nav_data_fraction=0.3;
     else
         if(isempty(ice_obj.nav_data_fraction))
             ice_obj.nav_data_fraction=0.3;
         end;
     end;
     
     %weighted least square fitting 
     if(ice_obj.flag_phase_cor_algorithm_lsq) %least-square
     for i=1:size(even,2)
         RR=abs(even(:,i).*odd(:,i));
         Rs=sort(RR);
         idx=find(RR>Rs(round(length(Rs)*(1-ice_obj.nav_data_fraction))));
         R=diag(RR(idx));
         RR=diag(RR);
         
         phase=unwrap(angle(even(idx,:)./odd(idx,:)));
         x=([0:size(even,1)-1]-size(even,1)/2+0.5)';
         XX=[x, ones(size(x))];
         X=XX(idx,:);
         
         phi(:,i)=inv(X'*pinv(R)*X)*X'*pinv(R)*phase(:,i);
     end;
     
    
     ice_obj.nav_phase_slope=phi(1,:)';
     ice_obj.nav_phase_offset=phi(2,:)';
    end;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if(ice_obj.flag_phase_cor_algorithm_jbm)    %jbm's algorithm
    %original JBM algorithm
    odd2=odd(1:end-1,:);
    odd1=odd(2:end,:);
    even2=even(1:end-1,:);
    even1=even(2:end,:);
    
    odd_linear_angle=angle(diag(odd1'*odd2));
    even_linear_angle=angle(diag(even1'*even2));
    
    offset=angle(diag(even'*odd));
    ice_obj.nav_phase_slope=odd_linear_angle-even_linear_angle;
    if(~ice_obj.flag_phase_cor_offset)
	ice_obj.nav_phase_offset=zeros(size(offset));
    else
	ice_obj.nav_phase_offset=-offset;
    end;
    end;
end;

% this is the previous implementation of JBM's phase correction
% odd2=odd(1:end-1,:);
% odd1=odd(2:end,:);
% even2=even(1:end-1,:);
% even1=even(2:end,:);
% odd_linear_angle=angle(diag(odd1'*odd2));
% even_linear_angle=angle(diag(even1'*even2));
% 
% offset=angle(diag(even'*odd));
% 
% ice_obj.nav_phase_slope=odd_linear_angle-even_linear_angle;
% ice_obj.nav_phase_offset=offset;
% ice_obj.nav_phase_offset=zeros(length(offset),1);
return;
