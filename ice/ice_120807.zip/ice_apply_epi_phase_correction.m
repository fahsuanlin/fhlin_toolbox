function []=ice_apply_epi_phase_correction(sMdh, sFifo)

global ice_m_data;
global ice_obj;

x=([0:sFifo.lDimX-1]-sFifo.lDimX/2+0.5)';
x=repmat(x,[1, sFifo.lDimC]);

offset=repmat(transpose(ice_obj.nav_phase_offset),[size(x,1),1]);

phi=exp(sqrt(-1).*(offset+x*diag(ice_obj.nav_phase_slope)));

%replicate phase correction term for multiple echoes
phi=repmat(phi,[1,1,size(ice_m_data,5)]);

if(~ice_obj.flag_3D)
	ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:,:)=squeeze(ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushSlice+1,:,:)).*squeeze(phi);
else
        ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushPartition+1,:,:)=squeeze(ice_m_data(:,sMdh.sLC.ushLine+1,sMdh.sLC.ushPartition+1,:,:)).*squeeze(phi);
end;

%sFifo.FCData=sFifo.FCData.*phi;

return;
